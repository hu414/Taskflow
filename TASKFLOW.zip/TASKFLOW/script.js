// Mobile menu
const menuBtn = document.getElementById('menuBtn');
const mobileMenu = document.getElementById('mobileMenu');
if (menuBtn) menuBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click', e=>{
    const target = document.querySelector(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault(); target.scrollIntoView({behavior:'smooth'});
    if (mobileMenu && !mobileMenu.classList.contains('hidden')) mobileMenu.classList.add('hidden');
  });
});

// Reveal on scroll
const io = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){ entry.target.classList.add('show'); io.unobserve(entry.target); }
  });
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

// Pricing toggle (monthly/yearly)
const toggle = document.getElementById('priceToggle');
const amounts = document.querySelectorAll('.amount');
function updatePrices(){
  amounts.forEach(a=>{
    const m = a.getAttribute('data-month'), y = a.getAttribute('data-year');
    a.textContent = `$${(toggle && toggle.checked) ? y : m}`;
  });
}
if (toggle){ toggle.addEventListener('change', updatePrices); updatePrices(); }

// Lightweight 3D tilt (no library)
function addTilt(el){
  const damp = 20; // lower = stronger tilt
  el.addEventListener('mousemove', (e)=>{
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `rotateX(${(-py*damp)}deg) rotateY(${(px*damp)}deg) translateZ(10px)`;
  });
  el.addEventListener('mouseleave', ()=>{ el.style.transform = 'rotateX(0) rotateY(0) translateZ(0)'; });
}
document.querySelectorAll('[data-tilt]').forEach(addTilt);
